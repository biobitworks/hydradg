# Statistical Audit — Successor Recovery

Recorded: 2026-08-29T22:29:12Z

## EXP-008
- Statistical state: **UNDERPOWERED**
- n_raw=300, valid_parse_rate=0.9066666666666666
- n_paired=2, discordant=(0,0)
- McNemar p: None
- Conclusion: effect not established (frozen verdict)

## EXP-009
- Statistical state: **UNDERPOWERED**
- ordering_established: False
- Exploratory secondary pattern NOT promoted

## Stage-2
- Statistical state: **DESCRIPTIVE_ONLY**
- n_raw=432, n_valid=414
- Terminal: FAILURE_LEARNING_BEHAVIOR_IMPROVEMENT_NOT_ESTABLISHED

## Deterministic reproduction
- R1 output root: 118e50b4e2efad00e889593a99e86b7eff09a8b8e75db29b338b399354bab2ed
- R2 output root: 118e50b4e2efad00e889593a99e86b7eff09a8b8e75db29b338b399354bab2ed
- R3 output root: 118e50b4e2efad00e889593a99e86b7eff09a8b8e75db29b338b399354bab2ed
- Gate: PASS

## No p-hacking statement
Endpoints unchanged post hoc. Negative/null/failed cells retained. No new model samples for significance.
